	<div id="popup-template">
    
    	<!--PHOTO-ITEM-->
       	<div class="photo-item">
                                	
      		<!--PHOTO-->
            <div id="main-image" class="autocrop-image" style="background-image:url(images/profile-him-popup.jpg)">
            </div>
                                            
        	<!--PHOTO OVERLAY-->
        	<div class="layer wh100 opacity-black-overlay">
        	</div><!--END of PHOTO OVERLAY-->
            
            <!--PHOTO CAPTION-->
        	<div class="layer wh100 photo-caption">
             	
                <div id="popup-template-title-wrapper">
               		<h1 style="color:#FFF">GERRARD LEANDRO</h1>
                                		
              		<div class="heart-divider">
                		<span class="white-line"></span>
        				<i class="de-icon-heart pink-heart"></i>
                		<i class="de-icon-heart white-heart"></i>
             			<span class="white-line"></span>
        			</div>
      			</div>
                
        	</div><!--END of PHOTO CAPTION-->
							
 		</div><!--END of PHOTO-ITEM-->  
        
        <!-- CONTENT -->
        <div id="the-content">
        	<div id="socialnetwork-icon">
        		<a href="#">
							<div class="de-icon circle outline medium-size inline">
								<i class="de-icon-facebook"></i>
            				</div>
        				</a>
                            
                        <a href="#">
        					<div class="de-icon circle outline medium-size inline">
            					<i class="de-icon-gplus"></i>
            				</div>
        				</a>
                            
                        <a href="#">
        					<div class="de-icon circle outline medium-size inline">
            					<i class="de-icon-twitter"></i>
            				</div>
        				</a>
            </div>                           
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis congue elementum augue, vel luctus dolor commodo eu. Nullam ac hendrerit ligula. Sed scelerisque adipiscing lorem at bibendum. Nam accumsan nulla eu ullamcorper semper. Sed viverra commodo sagittis. Quisque ut sem quis nunc blandit aliquam non sit amet erat. Donec sed fringilla orci. Aenean vehicula eros augue, in venenatis enim pretium sit amet.</p>
            <img src="images/attachment-9.jpg">      
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis congue elementum augue, vel luctus dolor commodo eu. Nullam ac hendrerit ligula. Sed scelerisque adipiscing lorem at bibendum. Nam accumsan nulla eu ullamcorper semper. Sed viverra commodo sagittis. Quisque ut sem quis nunc blandit aliquam non sit amet erat. Donec sed fringilla orci. Aenean vehicula eros augue, in venenatis enim pretium sit amet.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis congue elementum augue, vel luctus dolor commodo eu. Nullam ac hendrerit ligula. Sed scelerisque adipiscing lorem at bibendum. Nam accumsan nulla eu ullamcorper semper. Sed viverra commodo sagittis. Quisque ut sem quis nunc blandit aliquam non sit amet erat. Donec sed fringilla orci. Aenean vehicula eros augue, in venenatis enim pretium sit amet.</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis congue elementum augue, vel luctus dolor commodo eu. Nullam ac hendrerit ligula. Sed scelerisque adipiscing lorem at bibendum. Nam accumsan nulla eu ullamcorper semper. Sed viverra commodo sagittis. Quisque ut sem quis nunc blandit aliquam non sit amet erat. Donec sed fringilla orci. Aenean vehicula eros augue, in venenatis enim pretium sit amet.</p>
        </div><!--End of CONTENT-->
        
    </div><!--End of POPUP TEMPLATE 1-->